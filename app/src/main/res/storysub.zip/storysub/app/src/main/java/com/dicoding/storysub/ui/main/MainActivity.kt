package com.dicoding.storysub.ui.main

import android.content.Intent
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.storysub.BaseActivity
import kotlinx.coroutines.launch
import com.dicoding.storysub.R
import com.dicoding.storysub.adapter.StoryAdapter
import com.dicoding.storysub.databinding.ActivityMainBinding
import com.dicoding.storysub.ui.add.AddActivity
import com.dicoding.storysub.ui.maps.MapsActivity
import com.dicoding.storysub.ui.onBoarding.OnBoardingActivity
import com.dicoding.storysub.viewModelFactory.StoryViewModelFactory

class MainActivity : BaseActivity<ActivityMainBinding>() {

    private val viewModel by viewModels<MainViewModel> {
        StoryViewModelFactory.getInstance(this)
    }

    private lateinit var storyAdapter: StoryAdapter

    override fun getViewBinding(): ActivityMainBinding {
        return ActivityMainBinding.inflate(layoutInflater).also {
            setContentView(it.root)
        }
    }

    override fun setUI() {
        storyAdapter = StoryAdapter()
        binding.rvStory.adapter = storyAdapter
        setStoryData()
    }

    override fun setProcess() {
        binding.btnAdd.setOnClickListener {
            startActivity(Intent(this, AddActivity::class.java))
        }
        binding.btnLogout.setOnClickListener {
            viewModel.logout()
        }
        binding.topAppBar.setOnMenuItemClickListener {
            when (it.itemId) {
                R.id.action_item_one -> {
                    navigateToMaps()
                    true
                }

                else -> false
            }
        }
    }

    override fun setObserve() {
        viewModel.getSession().observe(this) { user ->
            if (user.token.isEmpty()) {
                startActivity(Intent(this, OnBoardingActivity::class.java))
                finish()
            } else {
//                setStoryData()
            }
        }
    }

    private fun setStoryData() {
        storyAdapter = StoryAdapter()
        binding.rvStory.adapter = storyAdapter
        viewModel.story.observe(this) {
            lifecycleScope.launch {
                storyAdapter.submitData(it)
            }
        }
        binding.rvStory.adapter = storyAdapter
        binding.rvStory.layoutManager = LinearLayoutManager(this)
    }

    private fun navigateToMaps() {
        val intent = Intent(this@MainActivity, MapsActivity::class.java)
        startActivity(intent)
    }
}