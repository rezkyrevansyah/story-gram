package com.dicoding.storysub.ui.register

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Intent
import android.view.View
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import com.dicoding.storysub.BaseActivity
import com.dicoding.storysub.R
import com.dicoding.storysub.data.response.ApiResponse
import com.dicoding.storysub.databinding.ActivityRegisterBinding
import com.dicoding.storysub.ui.login.LoginActivity
import com.dicoding.storysub.viewModelFactory.AuthViewModelFactory

class RegisterActivity : BaseActivity<ActivityRegisterBinding>() {

    private val viewModel by viewModels<RegisterViewModel> {
        AuthViewModelFactory.getInstance(this)
    }

    override fun getViewBinding(): ActivityRegisterBinding {
        return ActivityRegisterBinding.inflate(layoutInflater)
    }

    override fun setUI() {
        playAnimation()
    }

    override fun setProcess() {
        binding.register.setOnClickListener {
            register()
        }
    }

    override fun setObserve() {}

    private fun register() {
        val name = binding.etName.text.toString()
        val email = binding.etEmail.text.toString()
        val password = binding.etPassword.text.toString()

        viewModel.register(name, email, password).observe(this@RegisterActivity) {
            if (it != null) {
                when (it) {
                    is ApiResponse.Loading -> {
                        showLoading(true)
                    }

                    is ApiResponse.Success -> {
                        showLoading(false)
                        AlertDialog.Builder(this).apply {
                            setTitle(getString(R.string.registration_success))
                            val registerMessage = getString(R.string.registration_message)
                            setMessage(registerMessage)
                            setPositiveButton(getString(R.string.next)) { _, _ ->
                                val intent =
                                    Intent(this@RegisterActivity, LoginActivity::class.java)
                                intent.flags =
                                    Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                                startActivity(intent)
                                finish()
                            }
                            create()
                            show()
                        }
                    }

                    is ApiResponse.Error -> {
                        showLoading(false)
                        showToast(it.error)
                    }
                }
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    private fun playAnimation() {
        ObjectAnimator.ofFloat(binding.image, View.TRANSLATION_X, -30f, 30f).apply {
            duration = 6000
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
        }.start()

        val title = ObjectAnimator.ofFloat(binding.title, View.ALPHA, 1f).setDuration(150)
        val subtitle = ObjectAnimator.ofFloat(binding.subtitle, View.ALPHA, 1f).setDuration(150)
        val nameTextView = ObjectAnimator.ofFloat(binding.name, View.ALPHA, 1f).setDuration(150)
        val nameEditTextLayout =
            ObjectAnimator.ofFloat(binding.nameInput, View.ALPHA, 1f).setDuration(150)
        val emailTextView = ObjectAnimator.ofFloat(binding.email, View.ALPHA, 1f).setDuration(150)
        val emailEditTextLayout =
            ObjectAnimator.ofFloat(binding.emailInput, View.ALPHA, 1f).setDuration(150)
        val passwordTextView =
            ObjectAnimator.ofFloat(binding.password, View.ALPHA, 1f).setDuration(150)
        val passwordEditTextLayout =
            ObjectAnimator.ofFloat(binding.passwordInput, View.ALPHA, 1f).setDuration(150)
        val signup = ObjectAnimator.ofFloat(binding.register, View.ALPHA, 1f).setDuration(150)


        AnimatorSet().apply {
            playSequentially(
                title,
                subtitle,
                nameTextView,
                nameEditTextLayout,
                emailTextView,
                emailEditTextLayout,
                passwordTextView,
                passwordEditTextLayout,
                signup
            )
            startDelay = 100
        }.start()
    }

}