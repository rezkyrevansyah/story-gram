package com.dicoding.storysub.ui.maps

import androidx.activity.viewModels
import androidx.lifecycle.Observer
import com.dicoding.storysub.BaseActivity
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MarkerOptions
import com.dicoding.storysub.R
import com.dicoding.storysub.databinding.ActivityMapsBinding
import com.dicoding.storysub.viewModelFactory.StoryViewModelFactory

class MapsActivity : BaseActivity<ActivityMapsBinding>(), OnMapReadyCallback {

    private lateinit var mMap: GoogleMap

    private val boundsBuilder = LatLngBounds.Builder()

    private val viewModel by viewModels<MapsViewModel> {
        StoryViewModelFactory.getInstance(this)
    }

    override fun getViewBinding(): ActivityMapsBinding {
        return ActivityMapsBinding.inflate(layoutInflater)
    }

    override fun setUI() {
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun setProcess() {

    }

    override fun setObserve() {
        viewModel.getStoriesLocation()
    }

    override fun onMapReady(googleMap: GoogleMap) {
        mMap = googleMap

        mMap.uiSettings.isZoomControlsEnabled = true
        mMap.uiSettings.isIndoorLevelPickerEnabled = true
        mMap.uiSettings.isCompassEnabled = true
        mMap.uiSettings.isMapToolbarEnabled = true


        viewModel.story.observe(this, Observer { it ->
            it.listStory.forEach {
                val location = LatLng(it.lat!!, it.lon!!)
                mMap.addMarker(
                    MarkerOptions()
                        .position(location)
                        .title(it.name)
                        .snippet(it.description)
                )
                boundsBuilder.include(location)
            }
        })
    }
}