package com.dicoding.storysub.ui.maps

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import com.dicoding.storysub.data.repository.StoryRepository
import com.dicoding.storysub.data.response.StoryResponse

class MapsViewModel(private val repository: StoryRepository) : ViewModel() {

    private val _story = MutableLiveData<StoryResponse>()
    val story: LiveData<StoryResponse> = _story

    fun getStoriesLocation() {
        viewModelScope.launch {
            val response = repository.getStoriesLocation()
            _story.postValue(response)
        }
    }
}