package com.dicoding.storysub.ui.detail

import android.util.Log
import android.view.View
import androidx.activity.viewModels
import com.dicoding.storysub.BaseActivity
import com.dicoding.storysub.data.response.ApiResponse
import com.dicoding.storysub.data.response.Story
import com.dicoding.storysub.databinding.ActivityDetailBinding
import com.dicoding.storysub.utils.setImageUrl
import com.dicoding.storysub.viewModelFactory.StoryViewModelFactory

class DetailActivity : BaseActivity<ActivityDetailBinding>() {

    private val viewModel by viewModels<DetailViewModel> {
        StoryViewModelFactory.getInstance(this)
    }
    private lateinit var imageUrl: String

    override fun getViewBinding(): ActivityDetailBinding {
        return ActivityDetailBinding.inflate(layoutInflater)
    }

    override fun setUI() {}

    override fun setProcess() {}

    override fun setObserve() {
        val storyId = intent.getStringExtra(EXTRA_ID)
        viewModel.getSession().observe(this) { user ->
            if (user.token.isNotEmpty()) {
                if (storyId != null) {
                    viewModel.getStoryDetail(storyId).observe(this) { response ->
                        when (response) {
                            is ApiResponse.Loading -> {
                                showLoading(true)
                            }

                            is ApiResponse.Success -> {
                                viewModel.story.observe(this) { story ->
                                    showLoading(false)
                                    storyData(story)
                                    Log.d("Success", "Success get detail")
                                }
                                viewModel.getDetail(storyId)
                            }

                            is ApiResponse.Error -> {
                                showLoading(false)
                                showToast(response.error)
                            }
                        }
                    }
                }
            } else {
                showToast("Can't get ${user.email} token")
            }
        }
    }

    private fun storyData(story: Story) {
        binding.imgStoryPhoto.setImageUrl(story.photoUrl)
        binding.title.text = story.name
        binding.description.text = story.description
        imageUrl = story.photoUrl!!
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }

    companion object {
        const val EXTRA_PHOTO = "extra_photo"
        const val EXTRA_ID = "extra_id"
        const val EXTRA_TITLE = "extra_title"
    }
}