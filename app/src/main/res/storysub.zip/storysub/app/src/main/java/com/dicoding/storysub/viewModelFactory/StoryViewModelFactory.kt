package com.dicoding.storysub.viewModelFactory

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.dicoding.storysub.data.repository.StoryRepository
import com.dicoding.storysub.di.StoryInjection
import com.dicoding.storysub.ui.add.AddViewModel
import com.dicoding.storysub.ui.detail.DetailViewModel
import com.dicoding.storysub.ui.main.MainViewModel
import com.dicoding.storysub.ui.maps.MapsViewModel

class StoryViewModelFactory(private val repository: StoryRepository) :
    ViewModelProvider.NewInstanceFactory() {

    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(MainViewModel::class.java) -> {
                MainViewModel(repository) as T
            }

            modelClass.isAssignableFrom(DetailViewModel::class.java) -> {
                DetailViewModel(repository) as T
            }

            modelClass.isAssignableFrom(AddViewModel::class.java) -> {
                AddViewModel(repository) as T
            }

            modelClass.isAssignableFrom(MapsViewModel::class.java) -> {
                MapsViewModel(repository) as T
            }

            else -> throw IllegalArgumentException("Unknown ViewModel class: " + modelClass.name)
        }
    }

    companion object {
        @Volatile
        private var instance: StoryViewModelFactory? = null

        @JvmStatic
        fun getInstance(context: Context): StoryViewModelFactory {
            if (instance == null) {
                synchronized(StoryViewModelFactory::class.java) {
                    instance = StoryViewModelFactory(StoryInjection.provideStoryRepository(context))
                }
            }
            return instance as StoryViewModelFactory
        }
    }
}