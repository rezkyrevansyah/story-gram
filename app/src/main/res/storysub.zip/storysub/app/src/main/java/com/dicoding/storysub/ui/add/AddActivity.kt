package com.dicoding.storysub.ui.add

import android.content.Intent
import android.net.Uri
import android.util.Log
import android.view.View
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import com.dicoding.storysub.BaseActivity
import com.dicoding.storysub.data.response.ApiResponse
import com.dicoding.storysub.databinding.ActivityAddBinding
import com.dicoding.storysub.ui.main.MainActivity
import com.dicoding.storysub.utils.getImageUri
import com.dicoding.storysub.utils.uriToFile
import com.dicoding.storysub.viewModelFactory.StoryViewModelFactory

class AddActivity : BaseActivity<ActivityAddBinding>() {

    private var currentImageUri: Uri? = null

    private val viewModel by viewModels<AddViewModel> {
        StoryViewModelFactory.getInstance(this)
    }

    override fun getViewBinding(): ActivityAddBinding {
        return ActivityAddBinding.inflate(layoutInflater)
    }

    override fun setUI() {}

    override fun setProcess() {
        binding.galleryButton.setOnClickListener {
            startGallery()
        }
        binding.cameraButton.setOnClickListener {
            startCamera()
        }
        binding.submitButton.setOnClickListener {
            currentImageUri?.let { uri ->
                val description = binding.etDescription.text.toString()
                uploadStory(uri, description)
                showToast("Story Uploaded")
            } ?: showToast("Please select an image first")
        }
    }

    override fun setObserve() {}

    private fun startGallery() {
        launcherGallery.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    private fun startCamera() {
        currentImageUri = getImageUri(this)
        launcherIntentCamera.launch(currentImageUri!!)
    }

    private val launcherIntentCamera = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { isSuccess ->
        if (isSuccess) {
            showImage()
        }
    }

    private val launcherGallery = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            currentImageUri = uri
            showImage()
        } else {
            Log.d("Photo Picker", "No media selected")
        }
    }

    private fun showImage() {
        currentImageUri?.let {
            Log.d("Image URI", "showImage: $it")
            binding.imagePreview.setImageURI(it)
        }
    }

    private fun uploadStory(uri: Uri, description: String) {
        viewModel.getSession()
        viewModel.uploadStory(uriToFile(uri, this), description).observe(this) { response ->
            when (response) {
                is ApiResponse.Loading -> {
                    showLoading(true)
                }

                is ApiResponse.Success -> {
                    val intent = Intent(this@AddActivity, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
                    startActivity(intent)
                    finish()
                }

                is ApiResponse.Error -> {
                    showLoading(false)
                    showToast(response.error)
                }
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}